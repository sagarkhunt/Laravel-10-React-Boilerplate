# Security Policy

If you discover any security related issues, please email nilanth.dev@gmail.com instead of using the issue tracker.
