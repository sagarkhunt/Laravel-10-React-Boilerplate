
function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Laravel React Boilerplate</h1>
    </div>
  );
}

export default Dashboard;
